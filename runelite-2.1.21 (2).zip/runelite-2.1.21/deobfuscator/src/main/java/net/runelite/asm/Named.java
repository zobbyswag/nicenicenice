package net.runelite.asm;

public interface Named
{
	String getName();
}
